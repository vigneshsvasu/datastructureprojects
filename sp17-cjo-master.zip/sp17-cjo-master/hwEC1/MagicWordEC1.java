public class MagicWordEC1 {
	public static String magicWordMainSurvey() {
		/* replace magicWord with the magic word given to you when
		 * you finished the survey. */
		String magicWordMainSurvey = "penelope";
		return magicWordMainSurvey;
	}

	public static String magicWordTASurvey() {
		/* replace magicWord with the magic word given to you when
		 * you finished the TA survey. */
		String magicWordTASurvey = "penelope";
		return magicWordTASurvey;
	}
} 
