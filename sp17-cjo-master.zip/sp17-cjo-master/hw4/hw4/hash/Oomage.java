package hw4.hash;

public interface Oomage {
    void draw(double x, double y, double scalingFactor);
} 
