package db;

public class Database {
    public Database() {
        // YOUR CODE HERE
    }

    public String transact(String query) {
        return "YOUR CODE HERE";
    }
}
