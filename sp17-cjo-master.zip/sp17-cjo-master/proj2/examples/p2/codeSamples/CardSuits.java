package p2.codeSamples;

public enum CardSuits {
    DIAMONDS, HEARTS, SPADES, CLUBS
}