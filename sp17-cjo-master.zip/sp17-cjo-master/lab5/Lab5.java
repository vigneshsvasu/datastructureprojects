/** Submit this file to mark yourself as having attended lab 5.
 *  Make sure that your TA also marks your attendance in the attendance sheet.
 */

public class Lab5 {
	/* Change this to true when ready to submit. */
	public static boolean attendedLab = true;
}