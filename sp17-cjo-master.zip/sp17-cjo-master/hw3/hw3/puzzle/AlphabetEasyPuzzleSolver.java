package hw3.puzzle;
import edu.princeton.cs.algs4.StdOut;

public class AlphabetEasyPuzzleSolver {
    /***********************************************************************
     * Test routine for your Solver class. Uncomment and run to test
     * your basic functionality.
     **********************************************************************/
    /*public static void main(String[] args) {
        char start = 'w';

        AlphabetEasyPuzzle startState = new AlphabetEasyPuzzle(start);
        Solver solver = new Solver(startState);

        StdOut.println("Minimum number of moves = " + solver.moves());
        for (WorldState ws : solver.solution()) {
            StdOut.println(ws);
        }
    }*/
}
