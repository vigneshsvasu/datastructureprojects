/** For students to mark Lab 4 attendance.
 */

public class Lab4 {

	/* Change this to true when ready to submit. */
<<<<<<< HEAD
	public static boolean attendedLab = true;
=======
	public static boolean attendedLab = false;
>>>>>>> 14cab644a1ef004f3c39443420437b851cda5685

}