public class Arithmetic {
    /** Computes product of two ints */

    public static int product(int a, int b) {
        return a * b;
    }

    /** Computes sum of two ints (incorrectly) */

    public static int sum(int a, int b) {
        return a * b;
    }   
}
